//
//  ViewController.m
//  ios1
//
//  Created by Tracy Kim on 2/18/20.
//  Copyright © 2020 Tracy Kim. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *redhex;
@property (weak, nonatomic) IBOutlet UILabel *greenhex;
@property (weak, nonatomic) IBOutlet UILabel *bluehex;
@property (weak, nonatomic) IBOutlet UILabel *alphahex;
@property (weak, nonatomic) IBOutlet UIImageView *dog;
@property (weak, nonatomic) IBOutlet UILabel *piclabel;
@property (weak, nonatomic) IBOutlet UILabel *rednum;
@property (weak, nonatomic) IBOutlet UILabel *greennum;
@property (weak, nonatomic) IBOutlet UILabel *bluenum;
@property (weak, nonatomic) IBOutlet UILabel *alphanum;
@property (weak, nonatomic) IBOutlet UISlider *redslider;
@property (weak, nonatomic) IBOutlet UISlider *greenslider;
@property (weak, nonatomic) IBOutlet UISlider *blueslider;
@property (weak, nonatomic) IBOutlet UISlider *alphaslider;

@end

@implementation ViewController

- (IBAction)redSliderMoved:(id)sender {
    UISlider *myslider = (UISlider *) sender;
    
    int numred = (int) (myslider.value);
    
    NSString *displayNum1 = [[NSString alloc] initWithFormat:@"%d", numred];
    NSString *displayNumr = [[NSString alloc] initWithFormat:@"%x", numred];
    
    self.rednum.text = displayNum1;
    self.redhex.text = displayNumr;
    
    self.piclabel.backgroundColor = [UIColor colorWithRed:(self.redslider.value/255.0) green:(self.greenslider.value/255.0) blue:(self.blueslider.value/255.0) alpha:(self.alphaslider.value/255)];
    
}

- (IBAction)greenSliderMoved:(id)sender {
    UISlider *myslider = (UISlider *) sender;
    
    int numgreen = (int) (myslider.value);
    
    NSString *displayNum2 = [[NSString alloc] initWithFormat:@"%d", numgreen];
     NSString *displayNumg = [[NSString alloc] initWithFormat:@"%x", numgreen];
    
    self.greennum.text = displayNum2;
    self.greenhex.text = displayNumg;
    
    self.piclabel.backgroundColor = [UIColor colorWithRed:(self.redslider.value/255.0) green:(self.greenslider.value/255.0) blue:(self.blueslider.value/255.0) alpha:(self.alphaslider.value/255)];
    
}

- (IBAction)blueSliderMoved:(id)sender {
    UISlider *myslider = (UISlider *) sender;
    
    int numblue = (int) (myslider.value);
    
    NSString *displayNum3 = [[NSString alloc] initWithFormat:@"%d", numblue];
    NSString *displayNumb = [[NSString alloc] initWithFormat:@"%x", numblue];
    
    self.bluenum.text = displayNum3;
    self.bluehex.text = displayNumb;
    
    self.piclabel.backgroundColor = [UIColor colorWithRed:(self.redslider.value/255.0) green:(self.greenslider.value/255.0) blue:(self.blueslider.value/255.0) alpha:(self.alphaslider.value/255)];
    
}

- (IBAction)alphaSliderMoved:(id)sender {
    UISlider *myslider = (UISlider *) sender;
    
    int numalpha = (int) (myslider.value);
    
    NSString *displayNum4 = [[NSString alloc] initWithFormat:@"%d", numalpha];
    NSString *displayNuma = [[NSString alloc] initWithFormat:@"%x", numalpha];
    
    self.alphanum.text = displayNum4;
    self.alphahex.text = displayNuma;
    
    self.piclabel.backgroundColor = [UIColor colorWithRed:(self.redslider.value/255.0) green:(self.greenslider.value/255.0) blue:(self.blueslider.value/255.0) alpha:(self.alphaslider.value/255)];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    int numg = arc4random_uniform(255);
    self.greenslider.value = numg;
    NSString* greenstr = [NSString stringWithFormat:@"%d",(int)self.greenslider.value];
    NSString *displayNumg= [[NSString alloc] initWithFormat:@"%x", (int)self.greenslider.value];
    self.greennum.text = greenstr;
    self.greenhex.text = displayNumg;

    
    int numr = arc4random_uniform(255);
    self.redslider.value = numr;
    NSString* redstr = [NSString stringWithFormat:@"%d",(int)self.redslider.value];
    NSString *displayNumr= [[NSString alloc] initWithFormat:@"%x", (int)self.redslider.value];
    self.redhex.text = displayNumr;
    self.rednum.text = redstr;
    
    int numb = arc4random_uniform(255);
    self.blueslider.value = numb;
    NSString* bluestr = [NSString stringWithFormat:@"%d",(int)self.blueslider.value];
    NSString *displayNumb= [[NSString alloc] initWithFormat:@"%x", (int)self.blueslider.value];
    self.bluenum.text = bluestr;
    self.bluehex.text = displayNumb;

    int numa = 255;
    self.alphaslider.value = numa;
    NSString* alphastr = [NSString stringWithFormat:@"%d",(int)self.alphaslider.value];
    NSString *displayNuma= [[NSString alloc] initWithFormat:@"%x", (int)self.alphaslider.value];
    self.alphanum.text = alphastr;
    self.alphahex.text = displayNuma;

    self.piclabel.backgroundColor = [UIColor colorWithRed:(self.redslider.value/255.0) green:(self.greenslider.value/255.0) blue:(self.blueslider.value/255.0) alpha:(self.alphaslider.value/255)];
    

}


@end



//
//  third3.m
//  HW3
//
//  Created by user166195 on 3/20/20.
//  Copyright © 2020 user166195. All rights reserved.
//

#import "third3.h"

@implementation third3

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.frame = CGRectMake(100,200,80,120);
        [[self view] addSubview:self];
    }
    return self;
}

/////  # 9b  drawRect
- (void)drawRect:(CGRect)rect {
    CGPoint center;
    CGFloat point1 = 150;
    CGFloat point2 = 100;
    
    center.x = self.frame.origin.x + self.frame.size.width / 2.0;
    center.y = self.frame.origin.y + self.frame.size.height / 2.0;
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextBeginPath(ctx);
    
    
    //gradient back ground
    CGFloat components [8] = {
        0.0, 0.0, 1.0, 1.0,
        0.0, 1.0, 0.0, 1.0
    };
 
    CGFloat locations[2] = { 0.0, 1. };
  CGColorSpaceRef colorSpace  = CGColorSpaceCreateDeviceRGB();
 
    CGGradientRef gradient = CGGradientCreateWithColorComponents(
                colorSpace,
                components,
                locations,
                (size_t)2);
 
    CGContextDrawLinearGradient(
                ctx,
                gradient,
                CGPointZero,
                CGPointMake(self.bounds.size.width, self.bounds.size.height),
                (CGGradientDrawingOptions)NULL);
 
    CGColorSpaceRelease(colorSpace);
 
    
    //rec using lines
   
    CGContextMoveToPoint(ctx, center.x-point1, center.y-point2);
    CGContextAddLineToPoint(ctx, center.x+point1, center.y - point2);
    CGContextAddLineToPoint(ctx, center.x+point1, center.y +point2);
    CGContextAddLineToPoint(ctx, center.x-point1, center.y+point2);
    CGContextSetFillColorWithColor(ctx, [[UIColor whiteColor] CGColor]);
    CGContextFillPath(ctx);

    //arc
      UIImage *arc = UIGraphicsGetImageFromCurrentImageContext();
       CGContextAddArc(ctx, self.center.x, self.center.y, 50.0, 0, 2*M_PI, 0);
       CGContextSetFillColorWithColor(ctx, [[UIColor redColor] CGColor]);
       CGContextFillPath(ctx);
       
       UIGraphicsEndImageContext();
    UIImageView *arcView = [[UIImageView alloc] initWithImage:arc];
    [self.view addSubview:arcView];
    
    CGContextClosePath(ctx);
    CGContextStrokePath(ctx);
    

}

@end

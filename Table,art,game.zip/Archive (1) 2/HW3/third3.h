//
//  third3.h
//  HW3
//
//  Created by user166195 on 3/20/20.
//  Copyright © 2020 user166195. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface third3 : UIView {
    
}
@property (weak, nonatomic) IBOutlet UIView *view;
@end

NS_ASSUME_NONNULL_END

//
//  FourthViewController.m
//  HW3
//
//  Created by user166195 on 3/9/20.
//  Copyright © 2020 user166195. All rights reserved.
//al

#import "FourthViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface FourthViewController ()
@property int score2;
@property bool isTouch;
@end

@implementation FourthViewController


- (void)loadView {
    [ super loadView ];
}

- (void)viewDidLoad {
    
    [ super viewDidLoad ];
    self.score2 = 0;
    
    
    self.isTouch = false;
    
    CGPoint origin;
    directionImage1 = CGPointMake((drand48()+0.5), -1.0);
    
    //////// set the random starting point
                 origin = ball2.layer.position;
    origin.x = arc4random_uniform(view1.frame.size.width-ball2.frame.size.width);
                 origin.y =50.0;
                 ball2.layer.position = origin;

    self.score2 = (int)[[NSUserDefaults standardUserDefaults] integerForKey:@"save"];

    
    NSInteger save = [[NSUserDefaults standardUserDefaults] integerForKey:@"save"];
    score.text = [NSString stringWithFormat:@"%d", self.score2];
    ////////// #6  SETUP TIMER
   timer = [ NSTimer scheduledTimerWithTimeInterval: 0.01
                                              target: self
                                            selector: @selector(handleTimer:)
                                            userInfo: nil
                                             repeats: YES
             ];
     
    
          
}


      /////////////////  #7   HANDLE TIMER
      - (void) handleTimer: (NSTimer *) timer {
          CGSize size;
          CGPoint origin;
          
          // Move the image1
          size = [ ball2 image ].size;
          
          //NSLog(@"%f %f", ball2.layer.position.x,ball2.layer.position.y);
          
          //NSLog(@"%f %f", directionImage1.x,directionImage1.y);
          
          if (ball2.layer.position.x <= ball2.frame.size.width / 2)
              directionImage1.x = 1.0;
          
          //random here?
          if (ball2.layer.position.x >= view1.frame.size.width - ball2.frame.size.width / 2)
              directionImage1.x = -1.0;
          
          if (ball2.layer.position.y <= ball2.frame.size.height)
              directionImage1.y = 1.0;
          
          //random here?
          if (ball2.layer.position.y >= view1.frame.size.height - ball2.frame.size.height / 2){  // bottom
              directionImage1.y = -1.0;
              
          }
          
          
          
         if (CGRectIntersectsRect(ball2.layer.frame, paddle.layer.frame)== true) {
             if (self.isTouch == false) {
                 self.isTouch = true;
                 
                 directionImage1.y = -1.0;
                 self.score2+=1;
                 NSInteger save = self.score2;
                 score.text= [NSString stringWithFormat: @"%d", (int)save] ;
                 [[NSUserDefaults standardUserDefaults] setInteger:save forKey:@"save"];[[NSUserDefaults standardUserDefaults] synchronize];
             }
         } else {
             self.isTouch = false;
         }
          
           //////// #9  MOVE image1
              origin = ball2.layer.position;
              origin.x += directionImage1.x;
              origin.y += directionImage1.y;
              ball2.layer.position = origin;


         
      }

- (IBAction)rightmove:(id)sender {
    CGPoint origin;
    origin = paddle.layer.position;
    if (origin.x <=(view1.frame.size.width-48)) {
        origin.x += 12.0;
    }
    paddle.layer.position = origin;
    
}

- (IBAction)leftmove:(id)sender {
    CGPoint origin;
       origin = paddle.layer.position;
    if (origin.x>=48) {
       origin.x -= 12.0;
    }
       paddle.layer.position = origin;
}


      @end




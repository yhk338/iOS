//
//  FourthViewController.h
//  HW3
//
//  Created by user166195 on 3/9/20.
//  Copyright © 2020 user166195. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
NS_ASSUME_NONNULL_BEGIN

@interface FourthViewController : UIViewController {
    //IBOutlet UIImageView *image1;
    CGPoint directionImage1, directionImage2;
    NSTimer *timer;
    IBOutlet UIImageView *ball2;
    IBOutlet UIButton *leftb;
    IBOutlet UIButton *rightb;
    IBOutlet UIImageView *paddle;
    IBOutlet UIView *view1;
    IBOutlet UILabel *score;
    NSInteger savescore;
}

///////////////// #2 TIMER

- (void) handleTimer: (NSTimer *) timer;


@end



NS_ASSUME_NONNULL_END
 

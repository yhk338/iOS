//
//  studentViewController.h
//  HW2
//
//  Created by Tracy Kim on 3/1/20.
//  Copyright © 2020 Tracy Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface studentViewController : UIViewController
@property (weak, nonatomic) NSString *studentt;
@property (weak, nonatomic) NSString *addresss;
@property (weak, nonatomic) IBOutlet UIImageView *imagevieww;
@property (weak, nonatomic) NSString *imagestring;
@end

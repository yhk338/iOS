//
//  ViewController.m
//  HW2
//
//  Created by Tracy Kim on 3/1/20.
//  Copyright © 2020 Tracy Kim. All rights reserved.
//

#import "ViewController.h"
#import "studentViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;
@property (weak, nonatomic) IBOutlet UITextField *student;
@property (weak, nonatomic) IBOutlet UITextField *address;
@property (weak, nonatomic) IBOutlet UITextField *midterm;
@property (weak, nonatomic) IBOutlet UITextField *final;
@property (weak, nonatomic) IBOutlet UITextField *hw1;
@property (weak, nonatomic) IBOutlet UITextField *hw2;
@property (weak, nonatomic) IBOutlet UITextField *hw3;
@property (weak, nonatomic) IBOutlet UIButton *createstudent;
@property (weak, nonatomic) IBOutlet UIButton *leftbutton;
@property (weak, nonatomic) IBOutlet UIButton *rightbutton;
@property (weak, nonatomic) IBOutlet UISlider* slider;
@property (strong, nonatomic) NSMutableArray *studentArray;
@property (strong, nonatomic) NSString *studentimage;
@property int indexnow;
@property int arraylength;

@property int seguebarPrevIndex;




//extern int indexnum = [self.studentArray count];
//[NSArray arrayWithObjects: @"John Doe", @"NY", @"50", @"50",@"50",@"50",@"5"]
@end
//createstudent.isHidden = true;
@implementation ViewController


- (IBAction)selectsegment:(id)sender {
//    self.studentArray[_indexnow][0] = self.student.text;
//     self.studentArray[_indexnow][1] = self.address.text;
//     self.studentArray[_indexnow][2] = self.midterm.text;
//     self.studentArray[_indexnow][3] = self.final.text;
//     self.studentArray[_indexnow][4] = self.hw1.text;
//     self.studentArray[_indexnow][5] = self.hw2.text;
//     self.studentArray[_indexnow][6] = self.hw3.text;
//     self.studentArray[_indexnow][7] = self.studentimage;
    //if (self.segment.selectedSegmentIndex==0  || self.segment.selectedSegmentIndex==2) {
       // [self performSegueWithIdentifier:@"displayinfoButton" sender:nill];
         //   }
    if (self.segment.selectedSegmentIndex==0) {
        
        //displayInfo
        self.student.text = self.studentArray[_indexnow][0];
        self.address.text = self.studentArray[_indexnow][1];
        self.midterm.text = self.studentArray[_indexnow][2];
        self.final.text = self.studentArray[_indexnow][3];
        self.hw1.text = self.studentArray[_indexnow][4];
        self.hw2.text = self.studentArray[_indexnow][5];
        self.hw3.text = self.studentArray[_indexnow][6];
        self.studentimage = self.studentArray[_indexnow][7];

           self.view.backgroundColor = UIColor.whiteColor;
          self.createstudent.hidden = YES;
          self.leftbutton.hidden = NO;
          self.rightbutton.hidden = NO;
        
        _seguebarPrevIndex = 0;

        
        //store updated info
        //self.studentArray[_indexnow][0] = self.student.text;
      }
    
    else if(self.segment.selectedSegmentIndex==1) {
        
        if (_seguebarPrevIndex == 2) {
            self.segment.selectedSegmentIndex = 2;
            _seguebarPrevIndex = 2;

            
        } else {
            //store any updated previous student info
            self.studentArray[_indexnow][0] = self.student.text;
            self.studentArray[_indexnow][1] = self.address.text;
            self.studentArray[_indexnow][2] = self.midterm.text;
            self.studentArray[_indexnow][3] = self.final.text;
            self.studentArray[_indexnow][4] = self.hw1.text;
            self.studentArray[_indexnow][5] = self.hw2.text;
            self.studentArray[_indexnow][6] = self.hw3.text;
            self.studentArray[_indexnow][7] = self.studentimage;
            
            //store any updated previous student info
            self.studentArray[_indexnow][0] = self.student.text;
            
            [self performSegueWithIdentifier:@"disinfo" sender:nil];
            
            self.view.backgroundColor = UIColor.whiteColor;
            self.slider.hidden = NO;
            self.segment.selectedSegmentIndex=0;
            
            _seguebarPrevIndex = 1;
        }

        
        
        
        

    }
    
    
    else if (self.segment.selectedSegmentIndex==2) {
        
        //store any updated previous student info
        self.studentArray[_indexnow][0] = self.student.text;
         self.studentArray[_indexnow][1] = self.address.text;
         self.studentArray[_indexnow][2] = self.midterm.text;
         self.studentArray[_indexnow][3] = self.final.text;
         self.studentArray[_indexnow][4] = self.hw1.text;
         self.studentArray[_indexnow][5] = self.hw2.text;
         self.studentArray[_indexnow][6] = self.hw3.text;
         self.studentArray[_indexnow][7] = self.studentimage;
        
                
        self.slider.hidden = YES;
        self.view.backgroundColor = UIColor.lightGrayColor;
        self.createstudent.hidden = NO;
        self.leftbutton.hidden = YES;
        self.rightbutton.hidden = YES;
        self.student.text = @"";
        self.address.text =@"";
        self.midterm.text =@"";
        self.final.text = @"";
        self.hw1.text = @"";
        self.hw2.text = @"";
        self.hw3.text = @"";
        
        _seguebarPrevIndex = 2;

    }
}
- (IBAction)sliderr:(id)sender {
    //store any updated previous student info
    self.studentArray[_indexnow][0] = self.student.text;
     self.studentArray[_indexnow][1] = self.address.text;
     self.studentArray[_indexnow][2] = self.midterm.text;
     self.studentArray[_indexnow][3] = self.final.text;
     self.studentArray[_indexnow][4] = self.hw1.text;
     self.studentArray[_indexnow][5] = self.hw2.text;
     self.studentArray[_indexnow][6] = self.hw3.text;
     self.studentArray[_indexnow][7] = self.studentimage;
    
    
    UISlider *myslider = (UISlider *) sender;
    
    _indexnow = (int) (myslider.value);
    
    
    
}

- (IBAction)leftb:(id)sender {
    //store any updated previous student info
    self.studentArray[_indexnow][0] = self.student.text;
    self.studentArray[_indexnow][1] = self.address.text;
    self.studentArray[_indexnow][2] = self.midterm.text;
    self.studentArray[_indexnow][3] = self.final.text;
    self.studentArray[_indexnow][4] = self.hw1.text;
    self.studentArray[_indexnow][5] = self.hw2.text;
    self.studentArray[_indexnow][6] = self.hw3.text;
    self.studentArray[_indexnow][7] = self.studentimage;
    
    if (_indexnow>0) {
        _indexnow--;
        self.student.text = self.studentArray[_indexnow][0];
        self.address.text = self.studentArray[_indexnow][1];
        self.midterm.text = self.studentArray[_indexnow][2];
        self.final.text = self.studentArray[_indexnow][3];
        self.hw1.text = self.studentArray[_indexnow][4];
        self.hw2.text = self.studentArray[_indexnow][5];
        self.hw3.text = self.studentArray[_indexnow][6];
        self.studentimage = self.studentArray[_indexnow][7];

    }
}
    
- (IBAction)rightb:(id)sender {
    //store any updated previous student info
    self.studentArray[_indexnow][0] = self.student.text;
     self.studentArray[_indexnow][1] = self.address.text;
     self.studentArray[_indexnow][2] = self.midterm.text;
     self.studentArray[_indexnow][3] = self.final.text;
     self.studentArray[_indexnow][4] = self.hw1.text;
     self.studentArray[_indexnow][5] = self.hw2.text;
     self.studentArray[_indexnow][6] = self.hw3.text;
     self.studentArray[_indexnow][7] = self.studentimage;
    
    if (_indexnow<(_arraylength-1)) {
        _indexnow++;
        self.student.text = self.studentArray[_indexnow][0];
        self.address.text = self.studentArray[_indexnow][1];
        self.midterm.text = self.studentArray[_indexnow][2];
        self.final.text = self.studentArray[_indexnow][3];
        self.hw1.text = self.studentArray[_indexnow][4];
        self.hw2.text = self.studentArray[_indexnow][5];
        self.hw3.text = self.studentArray[_indexnow][6];
        self.studentimage = self.studentArray[_indexnow][7];


    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    //store any updated previous student info
    self.studentArray[_indexnow][0] = self.student.text;
     self.studentArray[_indexnow][1] = self.address.text;
     self.studentArray[_indexnow][2] = self.midterm.text;
     self.studentArray[_indexnow][3] = self.final.text;
     self.studentArray[_indexnow][4] = self.hw1.text;
     self.studentArray[_indexnow][5] = self.hw2.text;
     self.studentArray[_indexnow][6] = self.hw3.text;
     self.studentArray[_indexnow][7] = self.studentimage;
    
    
    studentViewController *vc = segue.destinationViewController;
    vc.addresss = self.studentArray[_indexnow][1];
    vc.studentt = self.studentArray[_indexnow][0];
    vc.imagestring = self.studentimage;
    
}

- (IBAction)createnew:(id)sender {
    
    if ([self.student.text length] > 0 && [self.address.text length] > 0 &&[self.midterm.text length] > 0 &&[self.final.text length] > 0 &&[self.hw1.text length] > 0 && [self.hw2.text length] > 0 &&[self.hw3.text length] > 0) {
        
        //create a new student, a collction of info about the NEW student
        NSMutableArray *adds = [NSMutableArray arrayWithObjects: [NSString stringWithFormat:@"%@", self.student.text], [NSString stringWithFormat:@"%@", self.address.text], [NSString stringWithFormat:@"%@", self.midterm.text], [NSString stringWithFormat:@"%@", self.final.text], [NSString stringWithFormat:@"%@", self.hw1.text], [NSString stringWithFormat:@"%@", self.hw2.text], [NSString stringWithFormat:@"%@", self.hw3.text], @"imagenot.jpg", nil];
        
        
    
        //adding to the array of students
        [self.studentArray addObject: adds];
        
        _arraylength = _arraylength+1;
        
        self.segment.selectedSegmentIndex=0;
        _indexnow= (int)[_studentArray count]-1;
        
        self.student.text = self.studentArray[_indexnow][0];
        self.address.text = self.studentArray[_indexnow][1];
        self.midterm.text = self.studentArray[_indexnow][2];
        self.final.text = self.studentArray[_indexnow][3];
        self.hw1.text = self.studentArray[_indexnow][4];
        self.hw2.text = self.studentArray[_indexnow][5];
        self.hw3.text = self.studentArray[_indexnow][6];
        self.studentimage = self.studentArray[_indexnow][7];

        
        //now, to give illusion of page changed, we need to implement following changes so current view looks like "Update Info" page
        self.view.backgroundColor = UIColor.whiteColor;
        self.createstudent.hidden = YES;
        self.leftbutton.hidden = NO;
        self.rightbutton.hidden = NO;
        
        _seguebarPrevIndex = 2;

        
    }
}

//NSString *str = self.student.text;


- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _seguebarPrevIndex = 0;
    
    self.studentArray[_indexnow][0] = self.student.text;
     self.studentArray[_indexnow][1] = self.address.text;
     self.studentArray[_indexnow][2] = self.midterm.text;
     self.studentArray[_indexnow][3] = self.final.text;
     self.studentArray[_indexnow][4] = self.hw1.text;
     self.studentArray[_indexnow][5] = self.hw2.text;
     self.studentArray[_indexnow][6] = self.hw3.text;
     self.studentArray[_indexnow][7] = self.studentimage;
    

    self.createstudent.hidden = YES;
       
       
    self.studentArray = [[NSMutableArray alloc] init];
    //self.slider = [[UISlider alloc] init];
    self.slider.minimumValue = 0;
    self.slider.maximumValue = _arraylength-1;
    
    NSMutableArray *student1 = [NSMutableArray arrayWithObjects:@"John Doe", @"NY", @"50", @"50",@"50",@"50",@"50",@"person1.png", nil];
    NSMutableArray *student2 = [NSMutableArray arrayWithObjects: @"Tracy Kim", @"NJ", @"100", @"50",@"50",@"50",@"50",@"person2.png", nil];
    NSMutableArray *student3 = [NSMutableArray arrayWithObjects: @"herry Yu", @"NY", @"100", @"50",@"0",@"50",@"50", @"person3.png", nil];
    NSMutableArray *student4 = [NSMutableArray arrayWithObjects:@"James Ha", @"NY", @"50", @"50",@"50",@"50",@"50",@"person4.png", nil];
    NSMutableArray *student5 = [NSMutableArray arrayWithObjects: @"Kerry Li", @"NY", @"100", @"50",@"50",@"50",@"50",@"person5.png", nil];
   

    [self.studentArray addObject:student1];
    [self.studentArray addObject:student2];
    [self.studentArray addObject:student3];
    [self.studentArray addObject:student4];
       [self.studentArray addObject:student5];
     _indexnow=0;
    self.student.text = self.studentArray[_indexnow][0];
    self.address.text = self.studentArray[_indexnow][1];
    self.midterm.text = self.studentArray[_indexnow][2];
    self.final.text = self.studentArray[_indexnow][3];
    self.hw1.text = self.studentArray[_indexnow][4];
    self.hw2.text = self.studentArray[_indexnow][5];
    self.hw3.text = self.studentArray[_indexnow][6];
    self.studentimage = self.studentArray[_indexnow][7];
    _arraylength = (int)[_studentArray count];
    
      
    

    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end






//
//  studentViewController.m
//  HW2
//
//  Created by Tracy Kim on 3/1/20.
//  Copyright © 2020 Tracy Kim. All rights reserved.
//

#import "studentViewController.h"

@interface studentViewController ()
@property (weak, nonatomic) IBOutlet UITextField *studenttt;

@property (weak, nonatomic) IBOutlet UITextField *addressss;
@end

@implementation studentViewController

- (IBAction)backbutton:(id)sender {
    [self dismissViewControllerAnimated:YES completion:Nil];
   
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _studenttt.text = self.studentt;
    _addressss.text = self.addresss;
    _imagevieww.image = [UIImage imageNamed: self.imagestring];
     // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

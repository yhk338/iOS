//
//  main.m
//  HW2
//
//  Created by Tracy Kim on 3/1/20.
//  Copyright © 2020 Tracy Kim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
